//
//  Attributes.swift
//  IoTConnectDemo
//
//  Created by kirtan.vaghela on 20/06/23.
//

import Foundation

struct Attributes: Codable {
    let d: AttributesData?
}

struct AttributesData: Codable {
    let att: [Att]?
    let ct: Int?
    let dt: String?
    let ec: Int?
}

// MARK: - Att
struct Att: Codable {
    let d: [AttData]?
    let dt: Int?
    let p,tg: String?
}

struct AttData: Codable {
    let dt: Int?
    let dv, ln,tw,tg: String?
    let sq: Int?
}

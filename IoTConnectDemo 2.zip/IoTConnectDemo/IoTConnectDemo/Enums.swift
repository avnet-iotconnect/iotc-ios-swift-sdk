//
//  Enums.swift
//  IoTConnectDemo
//
//  Created by kirtan.vaghela on 16/06/23.
//

import Foundation

enum statusText:String{
    case disconnected = "Device Disconnected..."
    case connected = "Device Connected.."
}


import UIKit

class TableHeaderView: UITableViewHeaderFooterView {
    
    @IBOutlet  var lblSectionTitle : UILabel!
    
}

//
//  IoTConnect_2_0.h
//  IoTConnect_2.0
//
//  Created by kirtan.vaghela on 01/06/23.
//

#import <Foundation/Foundation.h>

//#import "GCDAsyncSocket.h"
//#import "GCDAsyncUdpSocket.h"

//! Project version number for IoTConnect_2_0.
FOUNDATION_EXPORT double IoTConnect_2_0VersionNumber;

//! Project version string for IoTConnect_2_0.
FOUNDATION_EXPORT const unsigned char IoTConnect_2_0VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IoTConnect_2_0/PublicHeader.h>


